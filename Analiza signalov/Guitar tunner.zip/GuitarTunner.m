function [retval] = GuitarTunner (input)

E1 = 329.63;
B = 246.94;
G = 196.00;
D = 146.83;
A = 110.00;
E6 = 82.41;

pkg load signal

%disp("Start recording...");
%recorder = audiorecorder(44000,16,1);
%recordblocking(recorder,3.5);
%audioarray = getaudiodata(recorder);
%soundsc(audioarray,44000);
%disp("End recording.");


%ZAJEMANJE ZVOKA IN TRANSFORMACJO

note  = input;%audioarray;%input;%audioread(input);
%soundsc(note,44000);

freqNote = fft(note,44000);
ampNote = abs(freqNote);

%MOZNI OGLED SIGNALA
%plot(ampNote);

%ANALIZIRANJE SIGNALA
[max_amp,max_indx] = max(ampNote);
%disp(max_indx);
[pks,loc,extra]=findpeaks(ampNote);
clc;
tabpks = [];
tabloc = [];
for i = 1:length(pks)
  if(pks(i)>550)
    tabpks = [tabpks pks(i)];
    tabloc = [tabloc loc(i)]; 
  endif
endfor

if(tabloc(1)<96&&tabloc(1)>50)
  max_indx = tabloc(1);
endif

if(tabloc(1)<222&&tabloc(1)>1724)
  max_indx = tabloc(1);
endif

%disp(tabloc(1));
%disp(tabpks(1));

%E-B = 330 - 247;
% E - 288 - B;
%B-G = 247 - 197;
% B - 222 - G;
%G-D = 197 - 147;
% G - 172 - D
%D-A = 147 - 110;
% D - 128.5 - A;
%A-E6 = 110 - 82;
% A - 96 - E6;

%DOLO�ANJE STRUNE IN NAVODILO ZA ZVI�AT/ZNI�AT TON
if(max_indx>330)
  disp("Zaigrana struna je E1 zni�ajte ton.");
  disp(max_indx);
  return;
endif
if(max_indx==330)
  disp("Zaigrana struna je E1");
  disp(max_indx);
  return;
endif
if(max_indx<330&&max_indx>288)
  disp("Zaigrana struna je E1 pove�ajte ton.");
  disp(max_indx);
  return;
endif

if(max_indx<288&&max_indx>247)
  disp("Zaigrana struna je B zni�ajte ton.");
  disp(max_indx);
  return;
endif
if(max_indx==247)
  disp("Zaigrana struna je B");
  disp(max_indx);
endif
if(max_indx<247&&max_indx>222)
  disp("Zaigrana struna je B pove�ajte ton.");
  disp(max_indx);
  return;
endif

if(max_indx<222&&max_indx>197)
  disp("Zaigrana struna je G zni�ajte ton.");
  disp(max_indx);
  return;
endif
if(max_indx==197)
  disp("Zaigrana struna je G");
  disp(max_indx);
endif
if(max_indx<197&&max_indx>172)
  disp("Zaigrana struna je G pove�ajte ton.");
  disp(max_indx);
  return;
endif

if(max_indx<172&&max_indx>147)
  disp("Zaigrana struna je D zni�ajte ton.");
  disp(max_indx);
  return;
endif
if(max_indx==147)
  disp("Zaigrana struna je D");
  disp(max_indx);
endif
if(max_indx<147&&max_indx>128.5)
  disp("Zaigrana struna je D pove�ajte ton.");
  disp(max_indx);
  return;
endif

if(max_indx<128.5&&max_indx>110)
  disp("Zaigrana struna je A zni�ajte ton.");
  disp(max_indx);
  return;
endif
if(max_indx==110)
  disp("Zaigrana struna je A");
  disp(max_indx);
endif
if(max_indx<110&&max_indx>96)
  disp("Zaigrana struna je A pove�ajte ton.");
  disp(max_indx);
  return;
endif

if(max_indx<96&&max_indx>83)
  disp(max_indx);
  disp("Zaigrana struna je E6 zni�ajte ton.");
  return;
endif
if(max_indx==83)
  disp("Zaigrana struna je E6");
  disp(max_indx);
endif
if(max_indx<83)
  disp("Zaigrana struna je E6 pove�ajte ton.");
  disp(max_indx);
  return;
endif



endfunction
