E1 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_ok\8393__speedy__clean-e1st-str-pick.wav');

B = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_ok\8385__speedy__clean-b-str-pick.wav');

G = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_ok\8402__speedy__clean-g-str-pick.wav');

D = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_ok\8388__speedy__clean-d-str-pick.wav');

A = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_ok\8382__speedy__clean-a-str-pick.wav');

E6 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_ok\8396__speedy__clean-e-str-pick.wav');

E401 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\01_E4\E4_01.wav');
E402 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\01_E4\E4_02.wav');
E403 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\01_E4\E4_03.wav');
E404 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\01_E4\E4_04.wav');
E405 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\01_E4\E4_05.wav');
E406 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\01_E4\E4_06.wav');
E407 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\01_E4\E4_07.wav');

B1 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\02_B3\B3_01.wav');
B2 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\02_B3\B3_02.wav');
B3 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\02_B3\B3_03.wav');
B4 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\02_B3\B3_04.wav');
B5 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\02_B3\B3_05.wav');
B6 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\02_B3\B3_06.wav');
B7 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\02_B3\B3_07.wav');

G1 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\03_G3\G3_01.wav');
G2 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\03_G3\G3_02.wav');
G3 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\03_G3\G3_03.wav');
G4 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\03_G3\G3_04.wav');
G5 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\03_G3\G3_05.wav');
G6 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\03_G3\G3_06.wav');
G7 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\03_G3\G3_07.wav');
G8 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\03_G3\G3_08.wav');

D1 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\04_D3\D3_01.wav');
D2 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\04_D3\D3_02.wav');
D3 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\04_D3\D3_03.wav');
D4 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\04_D3\D3_04.wav');
D5 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\04_D3\D3_05.wav');
D6 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\04_D3\D3_06.wav');

A1 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\05_A2\A2_01.wav');
A2 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\05_A2\A2_02.wav');
A3 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\05_A2\A2_03.wav');
A4 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\05_A2\A2_04.wav');
A5 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\05_A2\A2_05.wav');
A6 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\05_A2\A2_06.wav');
A7 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\05_A2\A2_07.wav');

E21 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\06_E2\E2_01.wav');
E22 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\06_E2\E2_02.wav');
E23 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\06_E2\E2_03.wav');
E24 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\06_E2\E2_04.wav');
E25 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\06_E2\E2_05.wav');
E26 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\06_E2\E2_06.wav');
E27 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\06_E2\E2_07.wav');
E28 = audioread('D:\FRI\DPS\Seminarska Naloga 1\guitar_bad\06_E2\E2_08.wav');